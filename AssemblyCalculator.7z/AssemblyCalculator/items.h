#ifndef ITEMS_H
#define ITEMS_H

const char *camtypes[3] = { "Bullet", "Dome", "other" };


#endif
